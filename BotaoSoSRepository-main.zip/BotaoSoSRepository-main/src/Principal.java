public class Principal {
    public static void main(String[] args) {
        BotaoSOSGUI gui = new BotaoSOSGUI();
    }
}